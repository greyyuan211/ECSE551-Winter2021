Place the unzipped folder in your drive and everything should work fine.

The code is well organized into sections and quite readable.

In the data folder, Diabetes RFE result and Red Wine RFE result are the results generated from 10 fold cross validated RFE algorithm. The tuples in each cell corresponds to accuracy and features deleted.

Diabetes RFE accuracy result and Red Wine RFE accuracy result are RFE results in cross validation accuracy only. 


Thank You!